let assert = require('assert');
let countries_and_timezones = require('countries-and-timezones');
// countries-and-timezones.getTimezone(name)
// function getTimezone(name) {
//     if (!timezones[name]) memoizeTimezone(buildTimezone(data, name));
//     return timezones[name] ? _objectSpread2({}, timezones[name]) : null;
//   }
describe('test countries_and_timezones', function() {
    it('test countries-and-timezones.getTimezone', function(done) {
