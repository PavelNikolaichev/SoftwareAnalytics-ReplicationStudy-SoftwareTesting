let assert = require('assert');
let countries_and_timezones = require('countries-and-timezones');
// usage #1
// const ct = require("countries-and-timezones");
// 
// const timezone = ct.getTimezone("America/Los_Angeles");
// console.log(timezone);
// 
// /*
// Prints:
// 
// {
//   name: 'America/Los_Angeles',
//   countries: [ 'US' ],
//   utcOffset: -480,
//   utcOffsetStr: '-08:00',
//   dstOffset: -420,
//   dstOffsetStr: '-07:00',
//   aliasOf: null
// }
// 
// */
// countries-and-timezones.getTimezone(name)
describe('test countries_and_timezones', function() {
    it('test countries-and-timezones.getTimezone', function(done) {
const assert = require('assert');
const ct = require('countries-and-timezones');

describe('test countries_and_timezones', function() {
    it('test countries-and-timezones.getTimezone', function(done) {
})})    })
    // the test above fails with the following error:
    //   Timeout of 2000ms exceeded. For async tests and hooks, ensure "done()" is called; if returning a Promise, ensure it resolves. (/path/to/test/test_13.js)
    // fixed test:
    it('test countries-and-timezones.getTimezone', function(done) {
