let assert = require('assert');
let countries_and_timezones = require('countries-and-timezones');
// countries-and-timezones.getAllCountries()
describe('test countries_and_timezones', function() {
    it('test countries-and-timezones.getAllCountries', function(done) {
