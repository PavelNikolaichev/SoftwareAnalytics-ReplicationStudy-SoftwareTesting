let assert = require('assert');
let countries_and_timezones = require('countries-and-timezones');
// usage #1
// const ct = require("countries-and-timezones");
// 
// const countries = ct.getAllCountries();
// console.log(countries);
// 
// /*
// Prints:
// 
// {
//   AD: {
//     id: 'AD',
//     name: 'Andorra',
//     timezones: [ 'Europe/Andorra' ]
//   },
//   AE: {
//     id: 'AE',
//     name: 'United Arab Emirates',
//     timezones: [ 'Asia/Dubai' ]
//   },
//   AF: {
// countries-and-timezones.getAllCountries()
// function getAllCountries() {
//     var options = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
//     return Object.keys(data.countries).reduce(function (previous, id) {
//       return Object.assign(previous, _defineProperty({}, id, getCountry(id, options)));
//     }, {});
//   }
describe('test countries_and_timezones', function() {
    it('test countries-and-timezones.getAllCountries', function(done) {
