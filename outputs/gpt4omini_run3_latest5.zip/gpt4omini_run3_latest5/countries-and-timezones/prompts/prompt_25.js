let assert = require('assert');
let countries_and_timezones = require('countries-and-timezones');
// countries-and-timezones.getAllCountries()
describe('test countries_and_timezones', function() {
    it('test countries-and-timezones.getAllCountries', function(done) {
let assert = require('assert');
let countries_and_timezones = require('countries-and-timezones');

describe('test countries_and_timezones', function() {
    it('test countries-and-timezones.getAllCountries', function(done) {
})})    })
    // the test above fails with the following error:
    //   Timeout of 2000ms exceeded. For async tests and hooks, ensure "done()" is called; if returning a Promise, ensure it resolves. (/path/to/test/test_16.js)
    // fixed test:
    it('test countries-and-timezones.getAllCountries', function(done) {
