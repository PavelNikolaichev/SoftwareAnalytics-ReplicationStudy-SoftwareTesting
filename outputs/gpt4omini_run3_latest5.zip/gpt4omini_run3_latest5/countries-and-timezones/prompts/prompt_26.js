let assert = require('assert');
let countries_and_timezones = require('countries-and-timezones');
// usage #1
// const ct = require("countries-and-timezones");
// 
// const countries = ct.getAllCountries();
// console.log(countries);
// 
// /*
// Prints:
// 
// {
//   AD: {
//     id: 'AD',
//     name: 'Andorra',
//     timezones: [ 'Europe/Andorra' ]
//   },
//   AE: {
//     id: 'AE',
//     name: 'United Arab Emirates',
//     timezones: [ 'Asia/Dubai' ]
//   },
//   AF: {
// countries-and-timezones.getAllCountries()
describe('test countries_and_timezones', function() {
    it('test countries-and-timezones.getAllCountries', function(done) {
