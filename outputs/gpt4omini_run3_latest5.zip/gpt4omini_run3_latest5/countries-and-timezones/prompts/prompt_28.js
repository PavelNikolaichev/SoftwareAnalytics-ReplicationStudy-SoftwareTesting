let assert = require('assert');
let countries_and_timezones = require('countries-and-timezones');
// countries-and-timezones.getAllTimezones()
describe('test countries_and_timezones', function() {
    it('test countries-and-timezones.getAllTimezones', function(done) {
