let assert = require('assert');
let countries_and_timezones = require('countries-and-timezones');
// countries-and-timezones.getAllTimezones()
// function getAllTimezones() {
//     var options = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
//     if (totalTimezones !== memoizedTimezones) for (var _i = 0, _Object$keys = Object.keys(data.timezones); _i < _Object$keys.length; _i++) {
//       var name = _Object$keys[_i];
//       getTimezone(name);
//     }
//     return deliverTimezones(timezones, options);
//   }
describe('test countries_and_timezones', function() {
    it('test countries-and-timezones.getAllTimezones', function(done) {
npm install mocha chai countries-and-timezones
```
    })
    // the test above fails with the following error:
    //   Invalid syntax
    // fixed test:
    it('test countries-and-timezones.getAllTimezones', function(done) {
