let assert = require('assert');
let countries_and_timezones = require('countries-and-timezones');
// usage #1
// const ct = require("countries-and-timezones");
// 
// const timezones = ct.getAllTimezones();
// console.log(timezones);
// 
// /*
// Prints:
// 
// {
//   "Africa/Abidjan": {
//     "name": "Africa/Abidjan",
//     "countries": [
//       "CI", "BF", "GH",
//       "GM", "GN", "ML",
//       "MR", "SH", "SL",
//       "SN", "TG"
//     ],
//     "utcOffset": 0,
//     "utcOffsetStr": "+00:00",
//     "dstOffset": 0,
// countries-and-timezones.getAllTimezones()
// function getAllTimezones() {
//     var options = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
//     if (totalTimezones !== memoizedTimezones) for (var _i = 0, _Object$keys = Object.keys(data.timezones); _i < _Object$keys.length; _i++) {
//       var name = _Object$keys[_i];
//       getTimezone(name);
//     }
//     return deliverTimezones(timezones, options);
//   }
describe('test countries_and_timezones', function() {
    it('test countries-and-timezones.getAllTimezones', function(done) {
describe('test countries_and_timezones', function() {
    it('test countries-and-timezones.getAllTimezones', function(done) {
        // Call the function to get all timezones
})})    })
    // the test above fails with the following error:
    //   Timeout of 2000ms exceeded. For async tests and hooks, ensure "done()" is called; if returning a Promise, ensure it resolves. (/path/to/test/test_21.js)
    // fixed test:
    it('test countries-and-timezones.getAllTimezones', function(done) {
