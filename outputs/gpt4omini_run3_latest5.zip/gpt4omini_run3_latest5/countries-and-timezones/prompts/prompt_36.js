let assert = require('assert');
let countries_and_timezones = require('countries-and-timezones');
// usage #1
// const ct = require("countries-and-timezones");
// 
// const timezones = ct.getAllTimezones();
// console.log(timezones);
// 
// /*
// Prints:
// 
// {
//   "Africa/Abidjan": {
//     "name": "Africa/Abidjan",
//     "countries": [
//       "CI", "BF", "GH",
//       "GM", "GN", "ML",
//       "MR", "SH", "SL",
//       "SN", "TG"
//     ],
//     "utcOffset": 0,
//     "utcOffsetStr": "+00:00",
//     "dstOffset": 0,
// countries-and-timezones.getAllTimezones()
describe('test countries_and_timezones', function() {
    it('test countries-and-timezones.getAllTimezones', function(done) {
let assert = require('assert');
let countries_and_timezones = require('countries-and-timezones');

describe('test countries_and_timezones', function() {
})    })
    // the test above fails with the following error:
    //   Timeout of 2000ms exceeded. For async tests and hooks, ensure "done()" is called; if returning a Promise, ensure it resolves. (/path/to/test/test_0.js)
    // fixed test:
    it('test countries-and-timezones.getAllTimezones', function(done) {
