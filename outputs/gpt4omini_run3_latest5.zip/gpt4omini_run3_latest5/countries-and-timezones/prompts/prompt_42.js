let assert = require('assert');
let countries_and_timezones = require('countries-and-timezones');
// usage #1
// const ct = require("countries-and-timezones");
// 
// const timezones = ct.getTimezonesForCountry("MX");
// console.log(timezones);
// 
// /*
// Prints:
// 
// [
//   {
//     "name": "America/Bahia_Banderas",
//     "countries": [ "MX" ],
//     "utcOffset": -360,
//     "utcOffsetStr": "-06:00",
//     "dstOffset": -300,
//     "dstOffsetStr": "-05:00",
//     "aliasOf": null
//   },
//   {
//     "name": "America/Cancun",
// countries-and-timezones.getTimezonesForCountry(countryId)
// function getTimezonesForCountry(countryId) {
//     var options = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : {};
//     var country = getCountry(countryId, options);
//     if (!country) return null;
//     var values = country.timezones || [];
//     return values.map(function (timezone) {
//       return getTimezone(timezone);
//     });
//   }
describe('test countries_and_timezones', function() {
    it('test countries-and-timezones.getTimezonesForCountry', function(done) {
let assert = require('assert');
    })
    // the test above fails with the following error:
    //   Timeout of 2000ms exceeded. For async tests and hooks, ensure "done()" is called; if returning a Promise, ensure it resolves. (/path/to/test/test_3.js)
    // fixed test:
    it('test countries-and-timezones.getTimezonesForCountry', function(done) {
