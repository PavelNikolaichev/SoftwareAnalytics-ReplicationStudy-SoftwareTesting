let assert = require('assert');
let countries_and_timezones = require('countries-and-timezones');
// usage #1
// const ct = require("countries-and-timezones");
// 
// const timezones = ct.getTimezonesForCountry("MX");
// console.log(timezones);
// 
// /*
// Prints:
// 
// [
//   {
//     "name": "America/Bahia_Banderas",
//     "countries": [ "MX" ],
//     "utcOffset": -360,
//     "utcOffsetStr": "-06:00",
//     "dstOffset": -300,
//     "dstOffsetStr": "-05:00",
//     "aliasOf": null
//   },
//   {
//     "name": "America/Cancun",
// countries-and-timezones.getTimezonesForCountry(countryId)
describe('test countries_and_timezones', function() {
    it('test countries-and-timezones.getTimezonesForCountry', function(done) {
