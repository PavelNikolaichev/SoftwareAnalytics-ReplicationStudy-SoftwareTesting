let assert = require('assert');
let countries_and_timezones = require('countries-and-timezones');
// countries-and-timezones.getCountriesForTimezone(tzName)
describe('test countries_and_timezones', function() {
    it('test countries-and-timezones.getCountriesForTimezone', function(done) {
