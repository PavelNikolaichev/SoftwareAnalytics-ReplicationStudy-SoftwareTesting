let assert = require('assert');
let countries_and_timezones = require('countries-and-timezones');
// countries-and-timezones.getCountriesForTimezone(tzName)
// function getCountriesForTimezone(tzName) {
//     var options = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : {};
//     var timezone = getTimezone(tzName) || {};
//     var values = timezone.countries || [];
//     return values.map(function (c) {
//       return getCountry(c, options);
//     });
//   }
describe('test countries_and_timezones', function() {
    it('test countries-and-timezones.getCountriesForTimezone', function(done) {
