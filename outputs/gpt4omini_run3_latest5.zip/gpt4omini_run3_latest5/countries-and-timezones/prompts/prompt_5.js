let assert = require('assert');
let countries_and_timezones = require('countries-and-timezones');
// countries-and-timezones.getCountry(id)
// function getCountry(id) {
//     var options = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : {};
//     if (!countries[id]) memoizeCountry(buildCountry(data, id));
//     return deliverCountry(countries[id], options);
//   }
describe('test countries_and_timezones', function() {
    it('test countries-and-timezones.getCountry', function(done) {
let assert = require('assert');
let countries_and_timezones = require('countries-and-timezones');

describe('test countries_and_timezones', function() {
})    })
    // the test above fails with the following error:
    //   Timeout of 2000ms exceeded. For async tests and hooks, ensure "done()" is called; if returning a Promise, ensure it resolves. (/path/to/test/test_0.js)
    // fixed test:
    it('test countries-and-timezones.getCountry', function(done) {
