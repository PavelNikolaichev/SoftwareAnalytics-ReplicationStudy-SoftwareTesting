let assert = require('assert');
let countries_and_timezones = require('countries-and-timezones');
// usage #1
// const ct = require("countries-and-timezones");
// 
// const timezone = ct.getCountriesForTimezone("Europe/Zurich");
// console.log(timezone);
// 
// /*
// Prints:
// 
// [
//   {
//     "id": "CH",
//     "name": "Switzerland",
//     "timezones": [
//       "Europe/Zurich"
//     ]
//   },
//   {
//     "id": "DE",
//     "name": "Germany",
//     "timezones": [
// countries-and-timezones.getCountriesForTimezone(tzName)
// function getCountriesForTimezone(tzName) {
//     var options = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : {};
//     var timezone = getTimezone(tzName) || {};
//     var values = timezone.countries || [];
//     return values.map(function (c) {
//       return getCountry(c, options);
//     });
//   }
describe('test countries_and_timezones', function() {
    it('test countries-and-timezones.getCountriesForTimezone', function(done) {
npm install mocha chai countries-and-timezones
```
    })
    // the test above fails with the following error:
    //   Invalid syntax
    // fixed test:
    it('test countries-and-timezones.getCountriesForTimezone', function(done) {
