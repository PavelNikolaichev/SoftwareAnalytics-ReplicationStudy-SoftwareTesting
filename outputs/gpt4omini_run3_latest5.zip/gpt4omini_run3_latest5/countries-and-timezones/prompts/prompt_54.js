let assert = require('assert');
let countries_and_timezones = require('countries-and-timezones');
// usage #1
// const ct = require("countries-and-timezones");
// 
// const timezone = ct.getCountriesForTimezone("Europe/Zurich");
// console.log(timezone);
// 
// /*
// Prints:
// 
// [
//   {
//     "id": "CH",
//     "name": "Switzerland",
//     "timezones": [
//       "Europe/Zurich"
//     ]
//   },
//   {
//     "id": "DE",
//     "name": "Germany",
//     "timezones": [
// countries-and-timezones.getCountriesForTimezone(tzName)
describe('test countries_and_timezones', function() {
    it('test countries-and-timezones.getCountriesForTimezone', function(done) {
