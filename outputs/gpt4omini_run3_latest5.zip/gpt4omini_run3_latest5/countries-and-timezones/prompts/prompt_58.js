let assert = require('assert');
let countries_and_timezones = require('countries-and-timezones');
// countries-and-timezones.getCountryForTimezone(tzName)
// function getCountryForTimezone(tzName) {
//     var options = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : {};
//     var _getCountriesForTimez = getCountriesForTimezone(tzName, options),
//       _getCountriesForTimez2 = _slicedToArray(_getCountriesForTimez, 1),
//       main = _getCountriesForTimez2[0];
//     return main || null;
//   }
describe('test countries_and_timezones', function() {
    it('test countries-and-timezones.getCountryForTimezone', function(done) {
let assert = require('assert');
let countries_and_timezones = require('countries-and-timezones');

describe('test countries_and_timezones', function() {
})    })
    // the test above fails with the following error:
    //   Timeout of 2000ms exceeded. For async tests and hooks, ensure "done()" is called; if returning a Promise, ensure it resolves. (/path/to/test/test_0.js)
    // fixed test:
    it('test countries-and-timezones.getCountryForTimezone', function(done) {
