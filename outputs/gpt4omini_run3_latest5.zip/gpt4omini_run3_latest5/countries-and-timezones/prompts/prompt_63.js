let assert = require('assert');
let countries_and_timezones = require('countries-and-timezones');
// usage #1
// const ct = require("countries-and-timezones");
// 
// const timezone = ct.getCountryForTimezone("Europe/Zurich");
// console.log(timezone);
// 
// /*
// Prints:
// 
// {
//   "id": "CH",
//   "name": "Switzerland",
//   "timezones": [
//     "Europe/Zurich"
//   ]
// }
// 
// */
// countries-and-timezones.getCountryForTimezone(tzName)
describe('test countries_and_timezones', function() {
    it('test countries-and-timezones.getCountryForTimezone', function(done) {
