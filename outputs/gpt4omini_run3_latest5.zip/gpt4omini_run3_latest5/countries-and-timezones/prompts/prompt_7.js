let assert = require('assert');
let countries_and_timezones = require('countries-and-timezones');
// usage #1
// const ct = require("countries-and-timezones");
// 
// const country = ct.getCountry("DE");
// console.log(country);
// 
// /*
// Prints:
// 
// {
//   id: 'DE',
//   name: 'Germany',
//   timezones: [ 'Europe/Berlin', 'Europe/Zurich' ]
// }
// 
// */
// countries-and-timezones.getCountry(id)
describe('test countries_and_timezones', function() {
    it('test countries-and-timezones.getCountry', function(done) {
