let assert = require('assert');
let countries_and_timezones = require('countries-and-timezones');
// usage #1
// const ct = require("countries-and-timezones");
// 
// const country = ct.getCountry("DE");
// console.log(country);
// 
// /*
// Prints:
// 
// {
//   id: 'DE',
//   name: 'Germany',
//   timezones: [ 'Europe/Berlin', 'Europe/Zurich' ]
// }
// 
// */
// countries-and-timezones.getCountry(id)
describe('test countries_and_timezones', function() {
    it('test countries-and-timezones.getCountry', function(done) {
let assert = require('assert');
let countries_and_timezones = require('countries-and-timezones');

describe('test countries_and_timezones', function() {
    it('test countries-and-timezones.getCountry', function(done) {
})})    })
    // the test above fails with the following error:
    //   Timeout of 2000ms exceeded. For async tests and hooks, ensure "done()" is called; if returning a Promise, ensure it resolves. (/path/to/test/test_1.js)
    // fixed test:
    it('test countries-and-timezones.getCountry', function(done) {
