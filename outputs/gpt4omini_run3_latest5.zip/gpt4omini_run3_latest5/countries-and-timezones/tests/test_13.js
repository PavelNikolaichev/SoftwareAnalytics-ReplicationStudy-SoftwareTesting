let assert = require('assert');
let countries_and_timezones = require('countries-and-timezones');
describe('test suite', function() {
    it('test case', function(done) {
        const assert = require('assert');
const ct = require('countries-and-timezones');

describe('test countries_and_timezones', function() {
    it('test countries-and-timezones.getTimezone', function(done) {
})})    })
})