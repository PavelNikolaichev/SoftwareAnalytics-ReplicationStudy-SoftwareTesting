let assert = require('assert');
let countries_and_timezones = require('countries-and-timezones');
describe('test suite', function() {
    it('test case', function(done) {
        let assert = require('assert');
let countries_and_timezones = require('countries-and-timezones');

describe('test countries_and_timezones', function() {
    it('test countries-and-timezones.getAllTimezones', function(done) {
})})    })
})