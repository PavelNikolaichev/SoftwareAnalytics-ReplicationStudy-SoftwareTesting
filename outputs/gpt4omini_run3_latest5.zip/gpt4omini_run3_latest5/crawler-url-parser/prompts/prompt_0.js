let assert = require('assert');
let crawler_url_parser = require('crawler-url-parser');
// crawler-url-parser.parse(currentUrlStr, baseUrlStr)
describe('test crawler_url_parser', function() {
    it('test crawler-url-parser.parse', function(done) {
