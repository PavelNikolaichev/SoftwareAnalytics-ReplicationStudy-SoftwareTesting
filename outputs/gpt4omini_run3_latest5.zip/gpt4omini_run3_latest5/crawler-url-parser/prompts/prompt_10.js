let assert = require('assert');
let crawler_url_parser = require('crawler-url-parser');
// crawler-url-parser.extract(data, sourceUrl)
describe('test crawler_url_parser', function() {
    it('test crawler-url-parser.extract', function(done) {
