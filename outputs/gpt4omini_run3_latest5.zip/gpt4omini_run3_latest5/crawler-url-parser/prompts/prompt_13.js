let assert = require('assert');
let crawler_url_parser = require('crawler-url-parser');
// usage #1
// const cup = require('crawler-url-parser');
// 
// //// extract(html_str,current_url);
// let htmlStr='<html><body> \
//     <a href="http://best.question.stackoverflow.com">subdomain</a><br /> \
//     <a href="http://faq.stackoverflow.com">subdomain</a><br /> \
//     <a href="http://stackoverflow.com">updomain</a><br /> \
//     <a href="http://www.google.com">external</a><br /> \
//     <a href="http://www.facebook.com">external</a><br /> \
//     <a href="http://question.stackoverflow.com/aaa/bbb/ccc">sublevel</a><br /> \
//     <a href="http://question.stackoverflow.com/aaa/bbb/zzz">sublevel</a><br /> \
//     <a href="http://question.stackoverflow.com/aaa/">uplevel</a><br /> \
//     <a href="http://question.stackoverflow.com/aaa/ddd">samelevel</a><br /> \
//     <a href="http://question.stackoverflow.com/aaa/eee">samelevel</a><br /> \
//     <a href="http://question.stackoverflow.com/aaa/ddd/eee">internal</a><br /> \
//     <a href="http://question.stackoverflow.com/zzz">internal</a><br /> \
// </body></html>';
// 
// let currentUrl= "http://question.stackoverflow.com/aaa/bbb";
// let urls = cup.extract(htmlStr,currentUrl);
// crawler-url-parser.extract(data, sourceUrl)
// function extract(data, sourceUrl) {
// 	let urlMap = new Map();
// 	var baseUrl = parse(sourceUrl);
// 
// 	let $ = typeof data === "string" ? cheerio.load(data) : data;
// 	let embedBaseUrlStr = $('base').attr('href');
// 	let embedBaseUrl = parse(embedBaseUrlStr);
// 	baseUrl = embedBaseUrl ? embedBaseUrl : baseUrl;
// 	let baseUrlStr = baseUrl ? baseUrl.url : null;
// 
// 	$('a').each(function (i, el) {
// 		let href = $(this).attr('href');
// 		let text = $(this).text().trim();
// 		//href = href.replace(/;.*$/g,"");
// 		if (typeof href == "undefined" || href.length < 3 || /^(javascript|mailto:|ftp:)/ig.test(href)) return;
// 
// 		let currentUrl = parse(href, baseUrlStr);
// 
// 		if (currentUrl && currentUrl.url) {
// 			if (urlMap.has(currentUrl.url)) {
// 				let tmpUrl = urlMap.get(currentUrl.url);
// 				if (!tmpUrl.text.includes(text)) {
// 					tmpUrl.text = `${tmpUrl.text} ${text}`;
// 				}
// 			} else {
// 				currentUrl.text = text == null ? "" : text;
// 				currentUrl.baseurl = baseUrlStr;
// 				urlMap.set(currentUrl.url, currentUrl);
// 			}
// 		}
// 	});
// 
// 	//remove base url
// 	urlMap.delete(baseUrlStr);
// 
// 	for (let currentUrl of urlMap.values()) {
// 		currentUrl.type = gettype(currentUrl, baseUrl);
// 	}
// 
// 	let retArr = Array.from(urlMap.values());
// 
// 	retArr = retArr.map(function (el) {
// 		return {
// 			url: el.url,
// 			text: el.text,
// 			type: el.type
// 		}
// 	});
// 
// 	return retArr;
// }
describe('test crawler_url_parser', function() {
    it('test crawler-url-parser.extract', function(done) {
