let assert = require('assert');
let crawler_url_parser = require('crawler-url-parser');
// usage #1
// const cup = require('crawler-url-parser');
// 
// //// extract(html_str,current_url);
// let htmlStr='<html><body> \
//     <a href="http://best.question.stackoverflow.com">subdomain</a><br /> \
//     <a href="http://faq.stackoverflow.com">subdomain</a><br /> \
//     <a href="http://stackoverflow.com">updomain</a><br /> \
//     <a href="http://www.google.com">external</a><br /> \
//     <a href="http://www.facebook.com">external</a><br /> \
//     <a href="http://question.stackoverflow.com/aaa/bbb/ccc">sublevel</a><br /> \
//     <a href="http://question.stackoverflow.com/aaa/bbb/zzz">sublevel</a><br /> \
//     <a href="http://question.stackoverflow.com/aaa/">uplevel</a><br /> \
//     <a href="http://question.stackoverflow.com/aaa/ddd">samelevel</a><br /> \
//     <a href="http://question.stackoverflow.com/aaa/eee">samelevel</a><br /> \
//     <a href="http://question.stackoverflow.com/aaa/ddd/eee">internal</a><br /> \
//     <a href="http://question.stackoverflow.com/zzz">internal</a><br /> \
// </body></html>';
// 
// let currentUrl= "http://question.stackoverflow.com/aaa/bbb";
// let urls = cup.extract(htmlStr,currentUrl);
// crawler-url-parser.extract(data, sourceUrl)
describe('test crawler_url_parser', function() {
    it('test crawler-url-parser.extract', function(done) {
