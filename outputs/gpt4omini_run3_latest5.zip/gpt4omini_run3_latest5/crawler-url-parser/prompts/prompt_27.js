let assert = require('assert');
let crawler_url_parser = require('crawler-url-parser');
// usage #1
// const cup = require('crawler-url-parser');
// 
// //// gettype(current_url,base_url);
// let level = cup.gettype("sub.domain.com/aaa/bbb/","sub.domain.com/aaa/bbb/ccc");
// console.log(level); //sublevel
// 
// level = cup.gettype("sub.domain.com/aaa/bbb/ccc/ddd","sub.domain.com/aaa/bbb/ccc");
// console.log(level); //uplevel
// 
// level = cup.gettype("sub.domain.com/aaa/bbb/eee","sub.domain.com/aaa/bbb/ccc");
// console.log(level); //samelevel
// 
// level = cup.gettype("sub.domain.com/aaa/bbb/eee","sub.anotherdomain.com/aaa/bbb/ccc");
// console.log(level); //external
// crawler-url-parser.gettype(linkurl, pageurl)
describe('test crawler_url_parser', function() {
    it('test crawler-url-parser.gettype', function(done) {
