let assert = require('assert');
let crawler_url_parser = require('crawler-url-parser');
// crawler-url-parser.gettype(linkurl, pageurl)
describe('test crawler_url_parser', function() {
    it('test crawler-url-parser.gettype', function(done) {

    })
    // the test above fails with the following error:
    //   Empty test
    // fixed test:
    it('test crawler-url-parser.gettype', function(done) {
