let assert = require('assert');
let crawler_url_parser = require('crawler-url-parser');
// crawler-url-parser.parse(currentUrlStr, baseUrlStr)
describe('test crawler_url_parser', function() {
    it('test crawler-url-parser.parse', function(done) {
let assert = require('assert');
let crawler_url_parser = require('crawler-url-parser');

describe('test crawler_url_parser', function() {
})    })
    // the test above fails with the following error:
    //   Timeout of 2000ms exceeded. For async tests and hooks, ensure "done()" is called; if returning a Promise, ensure it resolves. (/path/to/test/test_1.js)
    // fixed test:
    it('test crawler-url-parser.parse', function(done) {
