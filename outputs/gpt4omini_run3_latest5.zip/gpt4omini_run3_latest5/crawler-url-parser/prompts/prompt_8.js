let assert = require('assert');
let crawler_url_parser = require('crawler-url-parser');
// usage #1
// const cup = require('crawler-url-parser');
// 
// //// parse(current_url[,base_url])
// let result = cup.parse("http://question.stackoverflow.com/aaa/bbb/ddd?q1=query1&q2=query2");
// 
// console.log(result.url);
// // http://question.stackoverflow.com/aaa/bbb/ddd?q1=query1&q2=query2
// 
// console.log(result.baseurl);
// // null
// 
// console.log(result.normalized);
// // http://question.stackoverflow.com/aaa/bbb/ddd?q1=query1&q2=query2
// 
// console.log(result.host); 
// // question.stackoverflow.com
// 
// console.log(result.domain); 
// // stackoverflow.com
// 
// usage #2
// const cup = require('crawler-url-parser');
// 
// //// parse(current_url[,base_url])
// let result = cup.parse("../ddd?q1=query1&q2=query2","http://question.stackoverflow.com/aaa/bbb/ccc/");
// 
// console.log(result.url);
// // http://question.stackoverflow.com/aaa/bbb/ddd?q1=query1&q2=query2
// 
// console.log(result.baseurl);
// // http://question.stackoverflow.com/aaa/bbb/ccc
// 
// console.log(result.normalized);
// // http://question.stackoverflow.com/aaa/bbb/ddd?q1=query1&q2=query2
// 
// console.log(result.host); 
// // question.stackoverflow.com
// 
// console.log(result.domain); 
// // stackoverflow.com
// 
// crawler-url-parser.parse(currentUrlStr, baseUrlStr)
describe('test crawler_url_parser', function() {
    it('test crawler-url-parser.parse', function(done) {
const assert = require('assert');
const cup = require('crawler-url-parser');

describe('test crawler_url_parser', function() {
    it('should parse a full URL correctly', function(done) {
})})    })
    // the test above fails with the following error:
    //   Timeout of 2000ms exceeded. For async tests and hooks, ensure "done()" is called; if returning a Promise, ensure it resolves. (/path/to/test/test_9.js)
    // fixed test:
    it('test crawler-url-parser.parse', function(done) {
