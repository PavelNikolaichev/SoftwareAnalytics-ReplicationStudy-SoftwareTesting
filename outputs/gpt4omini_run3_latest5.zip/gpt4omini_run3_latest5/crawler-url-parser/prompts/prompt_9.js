let assert = require('assert');
let crawler_url_parser = require('crawler-url-parser');
// crawler-url-parser.parse(currentUrlStr, baseUrlStr)
describe('test crawler_url_parser', function() {
    it('test crawler-url-parser.parse', function(done) {
npm install mocha assert crawler-url-parser
```
    })
    // the test above fails with the following error:
    //   Invalid syntax
    // fixed test:
    it('test crawler-url-parser.parse', function(done) {
