let assert = require('assert');
let crawler_url_parser = require('crawler-url-parser');

// Sample HTML data for testing
const sampleHtml = `