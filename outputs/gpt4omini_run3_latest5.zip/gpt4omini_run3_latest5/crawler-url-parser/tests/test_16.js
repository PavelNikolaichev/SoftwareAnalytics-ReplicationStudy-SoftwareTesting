let assert = require('assert');
let crawler_url_parser = require('crawler-url-parser');
describe('test suite', function() {
    it('test case', function(done) {
        // Expected output based on the provided HTML and current URL
        const expectedUrls = [
]    })
})