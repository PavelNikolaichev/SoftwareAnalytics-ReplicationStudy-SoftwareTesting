npm install mocha chai
```