let assert = require('assert');
let crawler_url_parser = require('crawler-url-parser');
describe('test suite', function() {
    it('test case', function(done) {
        const assert = require('assert');
const cup = require('crawler-url-parser');

describe('test crawler_url_parser', function() {
    it('should parse a full URL correctly', function(done) {
})})    })
})