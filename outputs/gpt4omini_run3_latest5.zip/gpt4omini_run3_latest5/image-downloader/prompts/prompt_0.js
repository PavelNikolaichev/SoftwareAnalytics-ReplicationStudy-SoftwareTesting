let assert = require('assert');
let image_downloader = require('image-downloader');
// image-downloader.image({ extractFilename = true, ...options } = {})
describe('test image_downloader', function() {
    it('test image-downloader.image', function(done) {
