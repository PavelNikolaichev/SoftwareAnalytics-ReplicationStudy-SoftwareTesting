let assert = require('assert');
let image_downloader = require('image-downloader');
// image-downloader.image({ extractFilename = true, ...options } = {})
// ({ extractFilename = true, ...options } = {}) => {
//   if (!options.url) {
//     return Promise.reject(new Error('The options.url is required'));
//   }
// 
//   if (!options.dest) {
//     return Promise.reject(new Error('The options.dest is required'));
//   }
// 
//   if (extractFilename) {
//     if (!path.extname(options.dest)) {
//       const url = new URL(options.url);
//       const pathname = url.pathname;
//       const basename = path.basename(pathname);
//       const decodedBasename = decodeURIComponent(basename);
// 
//       options.dest = path.join(options.dest, decodedBasename);
//     }
//   }
// 
//   if (!path.isAbsolute(options.dest)) {
//     options.dest = path.resolve(__dirname, options.dest);
//   }
// 
//   return request(options);
// }
describe('test image_downloader', function() {
    it('test image-downloader.image', function(done) {
