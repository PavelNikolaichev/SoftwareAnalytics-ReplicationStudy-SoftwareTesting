let assert = require('assert');
let image_downloader = require('image-downloader');
// image-downloader.image({ extractFilename = true, ...options } = {})
describe('test image_downloader', function() {
    it('test image-downloader.image', function(done) {
Here's a complete example of how you might write the test:
    })
    // the test above fails with the following error:
    //   Invalid syntax
    // fixed test:
    it('test image-downloader.image', function(done) {
