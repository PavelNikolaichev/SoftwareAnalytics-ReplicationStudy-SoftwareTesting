let assert = require('assert');
let image_downloader = require('image-downloader');
// usage #1
// const download = require('image-downloader');
// 
// const options = {
//   url: 'http://someurl.com/image.jpg',
//   dest: '/path/to/dest',               // will be saved to /path/to/dest/image.jpg
// };
// 
// download.image(options)
//   .then(({ filename }) => {
//     console.log('Saved to', filename); // saved to /path/to/dest/image.jpg
//   })
//   .catch((err) => console.error(err));
// usage #2
// const download = require('image-downloader');
// 
// options = {
//   url: 'http://someurl.com/image2.jpg',
//   dest: '/path/to/dest/photo.jpg',     // will be saved to /path/to/dest/photo.jpg
// };
// 
// download.image(options)
//   .then(({ filename }) => {
//     console.log('Saved to', filename); // saved to /path/to/dest/photo.jpg
//   })
//   .catch((err) => console.error(err));
// usage #3
// const download = require('image-downloader');
// 
// options = {
//   url: 'http://someurl.com/image3.jpg',
//   dest: '/path/to/dest/photo',         // will be saved to /path/to/dest/photo
//   extractFilename: false,
// };
// 
// download.image(options)
//   .then(({ filename }) => {
//     console.log('Saved to', filename), // saved to /path/to/dest/photo
//   })
//   .catch((err) => console.error(err));
// image-downloader.image({ extractFilename = true, ...options } = {})
describe('test image_downloader', function() {
    it('test image-downloader.image', function(done) {
Here's how you can structure your test:
    })
    // the test above fails with the following error:
    //   Invalid syntax
    // fixed test:
    it('test image-downloader.image', function(done) {
