const assert = require('assert');
const imageDownloader = require('image-downloader');
const path = require('path');

describe('test image_downloader', function()