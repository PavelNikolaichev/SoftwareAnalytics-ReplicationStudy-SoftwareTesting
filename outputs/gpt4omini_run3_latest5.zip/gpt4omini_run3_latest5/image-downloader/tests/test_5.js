npm install mocha chai image-downloader
```