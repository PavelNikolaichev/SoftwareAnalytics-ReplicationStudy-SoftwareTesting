npm install mocha chai image-downloader
```

Then, you can create a test file (e.g., `test/imageDownloader.test.js`)