let assert = require('assert');
let image_downloader = require('image-downloader');
describe('test suite', function() {
    it('test case', function(done) {
        const assert = require('assert');
    })
})