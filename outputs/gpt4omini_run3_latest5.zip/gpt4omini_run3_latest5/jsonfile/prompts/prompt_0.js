let assert = require('assert');
let jsonfile = require('jsonfile');
// jsonfile.readFile(...args)
describe('test jsonfile', function() {
    it('test jsonfile.readFile', function(done) {
