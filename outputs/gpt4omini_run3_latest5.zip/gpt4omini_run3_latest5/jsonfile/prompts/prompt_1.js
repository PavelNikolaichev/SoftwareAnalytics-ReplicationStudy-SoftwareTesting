let assert = require('assert');
let jsonfile = require('jsonfile');
// jsonfile.readFile(...args)
// function (...args) {
//     const cb = args[args.length - 1]
//     if (typeof cb !== 'function') return fn.apply(this, args)
//     else {
//       args.pop()
//       fn.apply(this, args).then(r => cb(null, r), cb)
//     }
//   }
describe('test jsonfile', function() {
    it('test jsonfile.readFile', function(done) {
