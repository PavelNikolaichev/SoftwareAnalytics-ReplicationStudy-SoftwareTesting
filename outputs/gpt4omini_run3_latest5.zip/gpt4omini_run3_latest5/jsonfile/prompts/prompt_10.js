let assert = require('assert');
let jsonfile = require('jsonfile');
// jsonfile.readFileSync(file, options = {})
describe('test jsonfile', function() {
    it('test jsonfile.readFileSync', function(done) {
