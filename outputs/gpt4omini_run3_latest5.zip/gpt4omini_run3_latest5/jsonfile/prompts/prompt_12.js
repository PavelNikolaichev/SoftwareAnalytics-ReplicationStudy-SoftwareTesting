let assert = require('assert');
let jsonfile = require('jsonfile');
// jsonfile.readFileSync(file, options = {})
// function readFileSync (file, options = {}) {
//   if (typeof options === 'string') {
//     options = { encoding: options }
//   }
// 
//   const fs = options.fs || _fs
// 
//   const shouldThrow = 'throws' in options ? options.throws : true
// 
//   try {
//     let content = fs.readFileSync(file, options)
//     content = stripBom(content)
//     return JSON.parse(content, options.reviver)
//   } catch (err) {
//     if (shouldThrow) {
//       err.message = `${file}: ${err.message}`
//       throw err
//     } else {
//       return null
//     }
//   }
// }
describe('test jsonfile', function() {
    it('test jsonfile.readFileSync', function(done) {
const assert = require('assert');
const jsonfile = require('jsonfile');
const fs = require('fs');
const path = require('path');
    })
    // the test above fails with the following error:
    //   Timeout of 2000ms exceeded. For async tests and hooks, ensure "done()" is called; if returning a Promise, ensure it resolves. (/path/to/test/test_15.js)
    // fixed test:
    it('test jsonfile.readFileSync', function(done) {
