let assert = require('assert');
let jsonfile = require('jsonfile');
// usage #1
// const jsonfile = require('jsonfile')
// const file = '/tmp/data.json'
// 
// console.dir(jsonfile.readFileSync(file))
// jsonfile.readFileSync(file, options = {})
// function readFileSync (file, options = {}) {
//   if (typeof options === 'string') {
//     options = { encoding: options }
//   }
// 
//   const fs = options.fs || _fs
// 
//   const shouldThrow = 'throws' in options ? options.throws : true
// 
//   try {
//     let content = fs.readFileSync(file, options)
//     content = stripBom(content)
//     return JSON.parse(content, options.reviver)
//   } catch (err) {
//     if (shouldThrow) {
//       err.message = `${file}: ${err.message}`
//       throw err
//     } else {
//       return null
//     }
//   }
// }
describe('test jsonfile', function() {
    it('test jsonfile.readFileSync', function(done) {
