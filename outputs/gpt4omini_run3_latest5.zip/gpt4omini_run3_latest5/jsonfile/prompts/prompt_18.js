let assert = require('assert');
let jsonfile = require('jsonfile');
// usage #1
// const jsonfile = require('jsonfile')
// const file = '/tmp/data.json'
// 
// console.dir(jsonfile.readFileSync(file))
// jsonfile.readFileSync(file, options = {})
describe('test jsonfile', function() {
    it('test jsonfile.readFileSync', function(done) {
