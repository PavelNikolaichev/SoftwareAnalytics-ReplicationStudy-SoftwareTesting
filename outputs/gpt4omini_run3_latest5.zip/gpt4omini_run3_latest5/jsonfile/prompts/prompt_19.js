let assert = require('assert');
let jsonfile = require('jsonfile');
// usage #1
// const jsonfile = require('jsonfile')
// const file = '/tmp/data.json'
// 
// console.dir(jsonfile.readFileSync(file))
// jsonfile.readFileSync(file, options = {})
describe('test jsonfile', function() {
    it('test jsonfile.readFileSync', function(done) {
It looks like you're starting to write a test case for the `jsonfile` library using Mocha, a popular JavaScript test framework. Below is a complete example of how you might structure your test case for `jsonfile.readFileSync`. This example assumes you have a JSON file at a specified path and that you want to verify its contents.
    })
    // the test above fails with the following error:
    //   Invalid syntax
    // fixed test:
    it('test jsonfile.readFileSync', function(done) {
