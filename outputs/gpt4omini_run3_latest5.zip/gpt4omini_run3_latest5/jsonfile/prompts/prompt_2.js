let assert = require('assert');
let jsonfile = require('jsonfile');
// jsonfile.readFile(...args)
// function (...args) {
//     const cb = args[args.length - 1]
//     if (typeof cb !== 'function') return fn.apply(this, args)
//     else {
//       args.pop()
//       fn.apply(this, args).then(r => cb(null, r), cb)
//     }
//   }
describe('test jsonfile', function() {
    it('test jsonfile.readFile', function(done) {
{
}    })
    // the test above fails with the following error:
    //   Timeout of 2000ms exceeded. For async tests and hooks, ensure "done()" is called; if returning a Promise, ensure it resolves. (/path/to/test/test_2.js)
    // fixed test:
    it('test jsonfile.readFile', function(done) {
