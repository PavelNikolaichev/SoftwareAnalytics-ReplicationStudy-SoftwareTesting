let assert = require('assert');
let jsonfile = require('jsonfile');
// jsonfile.writeFile(...args)
describe('test jsonfile', function() {
    it('test jsonfile.writeFile', function(done) {
