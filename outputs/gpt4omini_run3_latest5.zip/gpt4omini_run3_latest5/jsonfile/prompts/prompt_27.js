let assert = require('assert');
let jsonfile = require('jsonfile');
// jsonfile.writeFile(...args)
describe('test jsonfile', function() {
    it('test jsonfile.writeFile', function(done) {
let assert = require('assert');
let jsonfile = require('jsonfile');
let path = require('path');

describe('test jsonfile', function() {
})    })
    // the test above fails with the following error:
    //   Timeout of 2000ms exceeded. For async tests and hooks, ensure "done()" is called; if returning a Promise, ensure it resolves. (/path/to/test/test_28.js)
    // fixed test:
    it('test jsonfile.writeFile', function(done) {
