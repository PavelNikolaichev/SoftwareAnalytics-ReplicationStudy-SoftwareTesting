let assert = require('assert');
let jsonfile = require('jsonfile');
// usage #1
// const jsonfile = require('jsonfile')
// 
// const file = '/tmp/data.json'
// const obj = { name: 'JP' }
// 
// jsonfile.writeFile(file, obj, function (err) {
//   if (err) console.error(err)
// })
// usage #2
// const jsonfile = require('jsonfile')
// 
// const file = '/tmp/data.json'
// const obj = { name: 'JP' }
// 
// jsonfile.writeFile(file, obj)
//   .then(res => {
//     console.log('Write complete')
//   })
//   .catch(error => console.error(error))
// usage #3
// const jsonfile = require('jsonfile')
// 
// const file = '/tmp/data.json'
// const obj = { name: 'JP' }
// 
// jsonfile.writeFile(file, obj, { spaces: 2 }, function (err) {
//   if (err) console.error(err)
// })
// usage #4
// const jsonfile = require('jsonfile')
// 
// const file = '/tmp/data.json'
// const obj = { name: 'JP' }
// 
// jsonfile.writeFile(file, obj, { spaces: 2, EOL: '\r\n' }, function (err) {
//   if (err) console.error(err)
// })
// usage #5
// const jsonfile = require('jsonfile')
// 
// const file = '/tmp/data.json'
// const obj = { name: 'JP' }
// 
// jsonfile.writeFile(file, obj, { spaces: 2, finalEOL: false }, function (err) {
//   if (err) console.log(err)
// })
// usage #6
// const jsonfile = require('jsonfile')
// 
// const file = '/tmp/mayAlreadyExistedData.json'
// const obj = { name: 'JP' }
// 
// jsonfile.writeFile(file, obj, { flag: 'a' }, function (err) {
//   if (err) console.error(err)
// })
// jsonfile.writeFile(...args)
describe('test jsonfile', function() {
    it('test jsonfile.writeFile', function(done) {
const assert = require('assert');
    })
    // the test above fails with the following error:
    //   Timeout of 2000ms exceeded. For async tests and hooks, ensure "done()" is called; if returning a Promise, ensure it resolves. (/path/to/test/test_6.js)
    // fixed test:
    it('test jsonfile.writeFile', function(done) {
