let assert = require('assert');
let jsonfile = require('jsonfile');
// jsonfile.writeFileSync(file, obj, options = {})
describe('test jsonfile', function() {
    it('test jsonfile.writeFileSync', function(done) {
