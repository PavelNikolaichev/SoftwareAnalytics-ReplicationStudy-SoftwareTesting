let assert = require('assert');
let jsonfile = require('jsonfile');
// jsonfile.writeFileSync(file, obj, options = {})
// function writeFileSync (file, obj, options = {}) {
//   const fs = options.fs || _fs
// 
//   const str = stringify(obj, options)
//   // not sure if fs.writeFileSync returns anything, but just in case
//   return fs.writeFileSync(file, str, options)
// }
describe('test jsonfile', function() {
    it('test jsonfile.writeFileSync', function(done) {
