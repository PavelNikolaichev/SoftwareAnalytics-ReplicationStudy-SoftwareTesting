let assert = require('assert');
let jsonfile = require('jsonfile');
// jsonfile.writeFileSync(file, obj, options = {})
// function writeFileSync (file, obj, options = {}) {
//   const fs = options.fs || _fs
// 
//   const str = stringify(obj, options)
//   // not sure if fs.writeFileSync returns anything, but just in case
//   return fs.writeFileSync(file, str, options)
// }
describe('test jsonfile', function() {
    it('test jsonfile.writeFileSync', function(done) {
const assert = require('assert');
    })
    // the test above fails with the following error:
    //   Timeout of 2000ms exceeded. For async tests and hooks, ensure "done()" is called; if returning a Promise, ensure it resolves. (/path/to/test/test_6.js)
    // fixed test:
    it('test jsonfile.writeFileSync', function(done) {
