let assert = require('assert');
let jsonfile = require('jsonfile');
// usage #1
// const jsonfile = require('jsonfile')
// 
// const file = '/tmp/data.json'
// const obj = { name: 'JP' }
// 
// jsonfile.writeFileSync(file, obj)
// usage #2
// const jsonfile = require('jsonfile')
// 
// const file = '/tmp/data.json'
// const obj = { name: 'JP' }
// 
// jsonfile.writeFileSync(file, obj, { spaces: 2 })
// usage #3
// const jsonfile = require('jsonfile')
// 
// const file = '/tmp/data.json'
// const obj = { name: 'JP' }
// 
// jsonfile.writeFileSync(file, obj, { spaces: 2, EOL: '\r\n' })
// usage #4
// const jsonfile = require('jsonfile')
// 
// const file = '/tmp/data.json'
// const obj = { name: 'JP' }
// 
// jsonfile.writeFileSync(file, obj, { spaces: 2, finalEOL: false })
// usage #5
// const jsonfile = require('jsonfile')
// 
// const file = '/tmp/mayAlreadyExistedData.json'
// const obj = { name: 'JP' }
// 
// jsonfile.writeFileSync(file, obj, { flag: 'a' })
// jsonfile.writeFileSync(file, obj, options = {})
// function writeFileSync (file, obj, options = {}) {
//   const fs = options.fs || _fs
// 
//   const str = stringify(obj, options)
//   // not sure if fs.writeFileSync returns anything, but just in case
//   return fs.writeFileSync(file, str, options)
// }
describe('test jsonfile', function() {
    it('test jsonfile.writeFileSync', function(done) {
const fs = require('fs');
const path = require('path');
const assert = require('assert');
const jsonfile = require('jsonfile');
    })
    // the test above fails with the following error:
    //   Timeout of 2000ms exceeded. For async tests and hooks, ensure "done()" is called; if returning a Promise, ensure it resolves. (/path/to/test/test_33.js)
    // fixed test:
    it('test jsonfile.writeFileSync', function(done) {
