let assert = require('assert');
let jsonfile = require('jsonfile');
// usage #1
// const jsonfile = require('jsonfile')
// 
// const file = '/tmp/data.json'
// const obj = { name: 'JP' }
// 
// jsonfile.writeFileSync(file, obj)
// usage #2
// const jsonfile = require('jsonfile')
// 
// const file = '/tmp/data.json'
// const obj = { name: 'JP' }
// 
// jsonfile.writeFileSync(file, obj, { spaces: 2 })
// usage #3
// const jsonfile = require('jsonfile')
// 
// const file = '/tmp/data.json'
// const obj = { name: 'JP' }
// 
// jsonfile.writeFileSync(file, obj, { spaces: 2, EOL: '\r\n' })
// usage #4
// const jsonfile = require('jsonfile')
// 
// const file = '/tmp/data.json'
// const obj = { name: 'JP' }
// 
// jsonfile.writeFileSync(file, obj, { spaces: 2, finalEOL: false })
// usage #5
// const jsonfile = require('jsonfile')
// 
// const file = '/tmp/mayAlreadyExistedData.json'
// const obj = { name: 'JP' }
// 
// jsonfile.writeFileSync(file, obj, { flag: 'a' })
// jsonfile.writeFileSync(file, obj, options = {})
describe('test jsonfile', function() {
    it('test jsonfile.writeFileSync', function(done) {
const assert = require('assert');
const jsonfile = require('jsonfile');
const fs = require('fs');
const path = require('path');

describe('test jsonfile', function()
    })
    // the test above fails with the following error:
    //   Invalid syntax
    // fixed test:
    it('test jsonfile.writeFileSync', function(done) {
