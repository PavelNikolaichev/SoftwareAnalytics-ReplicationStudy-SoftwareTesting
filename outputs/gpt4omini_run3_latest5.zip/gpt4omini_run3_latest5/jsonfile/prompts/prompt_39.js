let assert = require('assert');
let jsonfile = require('jsonfile');
// usage #1
// const jsonfile = require('jsonfile')
// 
// const file = '/tmp/data.json'
// const obj = { name: 'JP' }
// 
// jsonfile.writeFileSync(file, obj)
// usage #2
// const jsonfile = require('jsonfile')
// 
// const file = '/tmp/data.json'
// const obj = { name: 'JP' }
// 
// jsonfile.writeFileSync(file, obj, { spaces: 2 })
// usage #3
// const jsonfile = require('jsonfile')
// 
// const file = '/tmp/data.json'
// const obj = { name: 'JP' }
// 
// jsonfile.writeFileSync(file, obj, { spaces: 2, EOL: '\r\n' })
// usage #4
// const jsonfile = require('jsonfile')
// 
// const file = '/tmp/data.json'
// const obj = { name: 'JP' }
// 
// jsonfile.writeFileSync(file, obj, { spaces: 2, finalEOL: false })
// usage #5
// const jsonfile = require('jsonfile')
// 
// const file = '/tmp/mayAlreadyExistedData.json'
// const obj = { name: 'JP' }
// 
// jsonfile.writeFileSync(file, obj, { flag: 'a' })
// jsonfile.writeFileSync(file, obj, options = {})
describe('test jsonfile', function() {
    it('test jsonfile.writeFileSync', function(done) {
const assert = require('assert');
    })
    // the test above fails with the following error:
    //   Timeout of 2000ms exceeded. For async tests and hooks, ensure "done()" is called; if returning a Promise, ensure it resolves. (/path/to/test/test_6.js)
    // fixed test:
    it('test jsonfile.writeFileSync', function(done) {
