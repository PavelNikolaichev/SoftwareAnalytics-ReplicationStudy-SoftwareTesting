let assert = require('assert');
let jsonfile = require('jsonfile');
// usage #1
// const jsonfile = require('jsonfile')
// const file = '/tmp/data.json'
// jsonfile.readFile(file, function (err, obj) {
//   if (err) console.error(err)
//   console.dir(obj)
// })
// usage #2
// const jsonfile = require('jsonfile')
// const file = '/tmp/data.json'
// jsonfile.readFile(file)
//   .then(obj => console.dir(obj))
//   .catch(error => console.error(error))
// jsonfile.readFile(...args)
// function (...args) {
//     const cb = args[args.length - 1]
//     if (typeof cb !== 'function') return fn.apply(this, args)
//     else {
//       args.pop()
//       fn.apply(this, args).then(r => cb(null, r), cb)
//     }
//   }
describe('test jsonfile', function() {
    it('test jsonfile.readFile', function(done) {
npm install mocha chai jsonfile
```
    })
    // the test above fails with the following error:
    //   Invalid syntax
    // fixed test:
    it('test jsonfile.readFile', function(done) {
