let assert = require('assert');
let jsonfile = require('jsonfile');
// usage #1
// const jsonfile = require('jsonfile')
// const file = '/tmp/data.json'
// jsonfile.readFile(file, function (err, obj) {
//   if (err) console.error(err)
//   console.dir(obj)
// })
// usage #2
// const jsonfile = require('jsonfile')
// const file = '/tmp/data.json'
// jsonfile.readFile(file)
//   .then(obj => console.dir(obj))
//   .catch(error => console.error(error))
// jsonfile.readFile(...args)
describe('test jsonfile', function() {
    it('test jsonfile.readFile', function(done) {
const assert = require('assert');
const jsonfile = require('jsonfile');
const path = require('path');

// Define the path to the JSON file
    })
    // the test above fails with the following error:
    //   Timeout of 2000ms exceeded. For async tests and hooks, ensure "done()" is called; if returning a Promise, ensure it resolves. (/path/to/test/test_10.js)
    // fixed test:
    it('test jsonfile.readFile', function(done) {
