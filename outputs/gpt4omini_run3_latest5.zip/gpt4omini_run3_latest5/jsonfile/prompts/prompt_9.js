let assert = require('assert');
let jsonfile = require('jsonfile');
// jsonfile.readFile(...args)
describe('test jsonfile', function() {
    it('test jsonfile.readFile', function(done) {
let assert = require('assert');
let jsonfile = require('jsonfile');
    })
    // the test above fails with the following error:
    //   Timeout of 2000ms exceeded. For async tests and hooks, ensure "done()" is called; if returning a Promise, ensure it resolves. (/path/to/test/test_0.js)
    // fixed test:
    it('test jsonfile.readFile', function(done) {
