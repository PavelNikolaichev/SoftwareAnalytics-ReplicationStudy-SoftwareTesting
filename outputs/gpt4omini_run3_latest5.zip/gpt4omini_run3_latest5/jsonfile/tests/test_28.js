let assert = require('assert');
let jsonfile = require('jsonfile');
describe('test suite', function() {
    it('test case', function(done) {
        let assert = require('assert');
let jsonfile = require('jsonfile');
let path = require('path');

describe('test jsonfile', function() {
})    })
})