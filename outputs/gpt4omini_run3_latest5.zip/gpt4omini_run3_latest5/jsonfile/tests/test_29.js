npm install jsonfile mocha assert
```