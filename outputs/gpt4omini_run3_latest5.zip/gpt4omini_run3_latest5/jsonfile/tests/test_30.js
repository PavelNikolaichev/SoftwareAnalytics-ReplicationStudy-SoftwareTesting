npm install jsonfile mocha assert
```

Then, you can create a test file (e.g., `test.js`)