let assert = require('assert');
let jsonfile = require('jsonfile');
describe('test suite', function() {
    it('test case', function(done) {
        const assert = require('assert');
const jsonfile = require('jsonfile');
const path = require('path');

describe('test jsonfile', function() {
})    })
})