const assert = require('assert');
const jsonfile = require('jsonfile');
const fs = require('fs');
const path = require('path');

describe('test jsonfile', function()