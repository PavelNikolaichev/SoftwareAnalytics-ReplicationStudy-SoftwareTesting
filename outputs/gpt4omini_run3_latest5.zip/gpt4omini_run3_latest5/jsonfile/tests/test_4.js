npm install mocha chai jsonfile fs-extra
```