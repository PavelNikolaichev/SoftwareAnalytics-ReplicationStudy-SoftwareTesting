npm install mocha chai jsonfile
```