let assert = require('assert');
let plural = require('plural');
// plural(word, num)
describe('test plural', function() {
    it('test plural', function(done) {
