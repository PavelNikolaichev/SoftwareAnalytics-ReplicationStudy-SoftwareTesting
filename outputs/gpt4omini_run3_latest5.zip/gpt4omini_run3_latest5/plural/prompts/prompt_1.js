let assert = require('assert');
let plural = require('plural');
// plural(word, num)
// function plural(word, num) {
//   var i
//     , rule
// 
//   if (num !== 1 || num === undefined) {
//     for (i = 0; i < rules.length; i++) {
//       rule = rules[i]
// 
//       if (type(rule[0]) === 'RegExp' && rule[0].test(word)) {
//         return type(rule[1]) === 'Function' ? rule[1](word, rule[0]) : rule[1]
//       }
//       if (type(rule[0]) === 'String' && rule[0] === word) {
//         return type(rule[1]) === 'Function' ? rule[1](word) : rule[1]
//       }
// 
//     }
// 
//     return word + 's'
//   }
//   return word
// }
describe('test plural', function() {
    it('test plural', function(done) {
