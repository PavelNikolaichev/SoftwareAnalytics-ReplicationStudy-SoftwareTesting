let assert = require('assert');
let plural = require('plural');
// plural.addRule(match, result)
// function addRule(match, result) {
//   rules.unshift([match, result])
//   return plural
// }
describe('test plural', function() {
    it('test plural.addRule', function(done) {
