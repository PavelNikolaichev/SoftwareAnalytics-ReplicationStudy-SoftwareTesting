let assert = require('assert');
let plural = require('plural');
// plural.addRule(match, result)
// function addRule(match, result) {
//   rules.unshift([match, result])
//   return plural
// }
describe('test plural', function() {
    it('test plural.addRule', function(done) {
let assert = require('assert');
    })
    // the test above fails with the following error:
    //   Timeout of 2000ms exceeded. For async tests and hooks, ensure "done()" is called; if returning a Promise, ensure it resolves. (/path/to/test/test_1.js)
    // fixed test:
    it('test plural.addRule', function(done) {
