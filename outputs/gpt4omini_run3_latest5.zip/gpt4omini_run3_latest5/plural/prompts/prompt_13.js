let assert = require('assert');
let plural = require('plural');
// plural.addRule(match, result)
describe('test plural', function() {
    it('test plural.addRule', function(done) {
let assert = require('assert');
let plural = require('plural');

// Add a custom pluralization rule
plural.addRule('person', 'people');
    })
    // the test above fails with the following error:
    //   Timeout of 2000ms exceeded. For async tests and hooks, ensure "done()" is called; if returning a Promise, ensure it resolves. (/path/to/test/test_12.js)
    // fixed test:
    it('test plural.addRule', function(done) {
