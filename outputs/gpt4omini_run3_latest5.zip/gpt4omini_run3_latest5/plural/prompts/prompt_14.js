let assert = require('assert');
let plural = require('plural');
// plural.addRule(match, result)
describe('test plural', function() {
    it('test plural.addRule', function(done) {
npm install plural
```

Here's how you can complete your test case:
    })
    // the test above fails with the following error:
    //   Invalid syntax
    // fixed test:
    it('test plural.addRule', function(done) {
