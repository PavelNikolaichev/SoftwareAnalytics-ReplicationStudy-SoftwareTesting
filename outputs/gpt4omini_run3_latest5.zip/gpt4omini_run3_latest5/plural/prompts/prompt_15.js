let assert = require('assert');
let plural = require('plural');
// plural.unmonkeyPatch()
describe('test plural', function() {
    it('test plural.unmonkeyPatch', function(done) {
