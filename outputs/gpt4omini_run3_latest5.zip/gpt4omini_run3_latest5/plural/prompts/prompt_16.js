let assert = require('assert');
let plural = require('plural');
// plural.unmonkeyPatch()
// function() {
//   String.prototype.plural = null;
// }
describe('test plural', function() {
    it('test plural.unmonkeyPatch', function(done) {
