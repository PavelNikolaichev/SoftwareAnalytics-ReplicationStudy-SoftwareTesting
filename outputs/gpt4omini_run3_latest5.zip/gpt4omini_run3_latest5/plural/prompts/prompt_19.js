let assert = require('assert');
let plural = require('plural');
// plural.unmonkeyPatch()
describe('test plural', function() {
    it('test plural.unmonkeyPatch', function(done) {

    })
    // the test above fails with the following error:
    //   Empty test
    // fixed test:
    it('test plural.unmonkeyPatch', function(done) {
