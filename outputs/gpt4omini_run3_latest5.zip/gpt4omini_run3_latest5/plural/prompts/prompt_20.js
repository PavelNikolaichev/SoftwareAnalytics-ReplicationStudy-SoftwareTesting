let assert = require('assert');
let plural = require('plural');
// plural.unmonkeyPatch()
describe('test plural', function() {
    it('test plural.unmonkeyPatch', function(done) {
Here's a complete example of how you might write the test:
    })
    // the test above fails with the following error:
    //   Invalid syntax
    // fixed test:
    it('test plural.unmonkeyPatch', function(done) {
