let assert = require('assert');
let plural = require('plural');
// plural.monkeyPatch()
describe('test plural', function() {
    it('test plural.monkeyPatch', function(done) {
