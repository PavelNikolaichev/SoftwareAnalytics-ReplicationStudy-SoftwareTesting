let assert = require('assert');
let plural = require('plural');
// plural.monkeyPatch()
// function() {
//   if (String.prototype.plural === undefined) {
//     String.prototype.plural = function(num) {
//       return plural(this, num)
//     }
//   }
//   else {
//     throw new Error('Unable to add plural function to String object')
//   }
// }
describe('test plural', function() {
    it('test plural.monkeyPatch', function(done) {
