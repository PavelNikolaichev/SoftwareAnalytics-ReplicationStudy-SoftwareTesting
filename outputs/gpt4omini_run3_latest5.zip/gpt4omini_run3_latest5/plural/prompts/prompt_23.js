let assert = require('assert');
let plural = require('plural');
// plural.monkeyPatch()
// function() {
//   if (String.prototype.plural === undefined) {
//     String.prototype.plural = function(num) {
//       return plural(this, num)
//     }
//   }
//   else {
//     throw new Error('Unable to add plural function to String object')
//   }
// }
describe('test plural', function() {
    it('test plural.monkeyPatch', function(done) {
It looks like you're working on a test case for a pluralization library in JavaScript. The code snippet you provided is a starting point for testing the `plural` library, specifically its ability to monkey-patch the `String` prototype to add a `plural` method.
    })
    // the test above fails with the following error:
    //   Invalid syntax
    // fixed test:
    it('test plural.monkeyPatch', function(done) {
