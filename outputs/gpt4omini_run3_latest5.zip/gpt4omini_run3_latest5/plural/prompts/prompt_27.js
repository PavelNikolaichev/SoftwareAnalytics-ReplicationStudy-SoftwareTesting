let assert = require('assert');
let plural = require('plural');
// plural.monkeyPatch()
// function() {
//   if (String.prototype.plural === undefined) {
//     String.prototype.plural = function(num) {
//       return plural(this, num)
//     }
//   }
//   else {
//     throw new Error('Unable to add plural function to String object')
//   }
// }
describe('test plural', function() {
    it('test plural.monkeyPatch', function(done) {
let assert = require('assert');
    })
    // the test above fails with the following error:
    //   Timeout of 2000ms exceeded. For async tests and hooks, ensure "done()" is called; if returning a Promise, ensure it resolves. (/path/to/test/test_1.js)
    // fixed test:
    it('test plural.monkeyPatch', function(done) {
