let assert = require('assert');
let plural = require('plural');
// usage #1
// var plural = require('plural')
// plural.monkeyPatch()
// 
// console.log('zebra'.plural(1))
// console.log('zebra'.plural(2))
// console.log('zebra'.plural())
// plural.monkeyPatch()
describe('test plural', function() {
    it('test plural.monkeyPatch', function(done) {
let assert = require('assert');
let plural = require('plural');

// Usage of plural library
    })
    // the test above fails with the following error:
    //   Timeout of 2000ms exceeded. For async tests and hooks, ensure "done()" is called; if returning a Promise, ensure it resolves. (/path/to/test/test_28.js)
    // fixed test:
    it('test plural.monkeyPatch', function(done) {
