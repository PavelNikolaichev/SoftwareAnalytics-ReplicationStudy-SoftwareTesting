let assert = require('assert');
let plural = require('plural');
// usage #1
// var plural = require('plural')
// plural.monkeyPatch()
// 
// console.log('zebra'.plural(1))
// console.log('zebra'.plural(2))
// console.log('zebra'.plural())
// plural.monkeyPatch()
describe('test plural', function() {
    it('test plural.monkeyPatch', function(done) {

    })
    // the test above fails with the following error:
    //   Empty test
    // fixed test:
    it('test plural.monkeyPatch', function(done) {
