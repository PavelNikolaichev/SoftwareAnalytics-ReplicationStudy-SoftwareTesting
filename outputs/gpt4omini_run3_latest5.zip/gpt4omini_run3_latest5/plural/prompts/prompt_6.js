let assert = require('assert');
let plural = require('plural');
// plural(word, num)
describe('test plural', function() {
    it('test plural', function(done) {
let assert = require('assert');
let plural = require('plural');

// plural(word, num)
describe('test plural', function() {
    it('should return the singular form for 1', function(done) {
})})    })
    // the test above fails with the following error:
    //   Timeout of 2000ms exceeded. For async tests and hooks, ensure "done()" is called; if returning a Promise, ensure it resolves. (/path/to/test/test_0.js)
    // fixed test:
    it('test plural', function(done) {
