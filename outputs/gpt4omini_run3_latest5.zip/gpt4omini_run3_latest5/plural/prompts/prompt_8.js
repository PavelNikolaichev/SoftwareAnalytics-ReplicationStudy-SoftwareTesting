let assert = require('assert');
let plural = require('plural');
// usage #1
// var plural = require('plural')
// 
// console.log(plural('zebra', 1)) // returns singular 'zebra'
// console.log(plural('zebra', 2)) // returns 'zebras'
// console.log(plural('zebra')) // returns 'zebras' (if no parameters, always returns plural)
// usage #2
// var plural = require('plural')
// plural.monkeyPatch()
// 
// console.log('zebra'.plural(1))
// console.log('zebra'.plural(2))
// console.log('zebra'.plural())
// plural(word, num)
describe('test plural', function() {
    it('test plural', function(done) {
let assert = require('assert');
let plural = require('plural');

// usage #1
// var plural = require('plural')
// 
// console.log(plural('zebra', 1)) // returns singular 'zebra'
    })
    // the test above fails with the following error:
    //   Timeout of 2000ms exceeded. For async tests and hooks, ensure "done()" is called; if returning a Promise, ensure it resolves. (/path/to/test/test_8.js)
    // fixed test:
    it('test plural', function(done) {
