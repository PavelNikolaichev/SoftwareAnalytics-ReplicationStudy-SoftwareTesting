let assert = require('assert');
let plural = require('plural');
// plural.addRule(match, result)
describe('test plural', function() {
    it('test plural.addRule', function(done) {
