npm install plural
```

Here's how you can complete your test case: