let assert = require('assert');
let plural = require('plural');
describe('test suite', function() {
    it('test case', function(done) {
        let assert = require('assert');
let plural = require('plural');

// Add a custom pluralization rule
plural.addRule('person', 'people');
    })
})