npm install mocha chai plural
```

Here’s a complete example of how you might write the test: