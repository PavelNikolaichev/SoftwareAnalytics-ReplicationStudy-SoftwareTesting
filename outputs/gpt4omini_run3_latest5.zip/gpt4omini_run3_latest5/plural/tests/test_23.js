let assert = require('assert');
let plural = require('plural');
describe('test suite', function() {
    it('test case', function(done) {
        let assert = require('assert');
let plural = require('plural');

// Uncomment the following line if you want to monkey patch the String prototype
    })
})