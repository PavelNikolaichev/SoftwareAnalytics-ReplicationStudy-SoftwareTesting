let assert = require('assert');
let plural = require('plural');
describe('test suite', function() {
    it('test case', function(done) {
        const assert = require('assert');
const plural = require('plural');

// Monkey patching the String prototype
    })
})