let assert = require('assert');
let plural = require('plural');
describe('test suite', function() {
    it('test case', function(done) {
        let assert = require('assert');
let plural = require('plural');

// Apply the monkey patch to String prototype
plural.monkeyPatch();

describe('test plural', function() {
})    })
})