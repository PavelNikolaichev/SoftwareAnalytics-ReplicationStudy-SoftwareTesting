npm install mocha chai plural
```