let assert = require('assert');
let plural = require('plural');
describe('test suite', function() {
    it('test case', function(done) {
        let assert = require('assert');
let plural = require('plural');

// plural(word, num)
describe('test plural', function() {
})    })
})