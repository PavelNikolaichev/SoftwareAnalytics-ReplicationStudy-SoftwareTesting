let assert = require('assert');
let plural = require('plural');
describe('test suite', function() {
    it('test case', function(done) {
        let assert = require('assert');
let plural = require('plural');

// usage #1
// var plural = require('plural')
// 
// console.log(plural('zebra', 1)) // returns singular 'zebra'
    })
})